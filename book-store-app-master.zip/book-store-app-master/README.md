# A Simple Book Store App

This is a simple app for managing your book list.

Features:
 - Can Add Books
 - Can Delete Books

Technology Used:
 - Vue Js 2.0
 - FireBase (Real Time Database)

Demo:
https://book-store-62cb3.firebaseapp.com/
